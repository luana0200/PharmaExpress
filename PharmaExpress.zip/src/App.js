import Rotas from "./router"

export default function App() {
  return (
     <div >
      <Rotas/>
     </div>
      
  );
}